﻿using System;
using Kids__Fair;

namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            PrepareConsoleLook(ConsoleColor.Cyan, ConsoleColor.Black, "KIDS' FAIR");

            Console.WriteLine("KIDS' FAIR system\n");

            Console.WriteLine("\n-----Pet Info Section-----");
            Pet pet = new();
            pet.Start();

            Console.WriteLine("\nPress enter to continue");
            Console.ReadLine();


            Console.WriteLine("\n-----Ticket Info Section-----");
            TicketSeller ticketSeller = new();
            ticketSeller.Start();

            Console.WriteLine("\nPress enter to continue");
            Console.ReadLine();

            Console.WriteLine("\n-----Album Info Section-----");
            Album album = new();
            album.Start();

            Console.WriteLine("\nThank you for trying this program. Press enter to close this program");
            Console.ReadLine();
        }
        static void PrepareConsoleLook(ConsoleColor backgroundColor, ConsoleColor foregroundColor, string title)
        {
            Console.BackgroundColor = backgroundColor;
            Console.Clear();
            Console.ForegroundColor = foregroundColor;
            Console.Title = title;
        }
    }
}