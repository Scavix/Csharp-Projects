﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Globalization;

namespace Kids__Fair
{
    internal class TicketSeller
    {
        private string name = string.Empty; //Variable for ticket name, init as empty string
        private double price = 100; //Variable for price
        private int numOfAdults; //Variable for number of adults, used for calculation of total amount
        private int numOfChildren; //Variable for number of children, used for calculation of total amount
        private double amountToPay; //Variable for total amount to pay
        public void Start()
        {
            ReadAndSaveTicketData();
            DisplayTicketInfo();
        }
        public void DisplayTicketInfo()
        {
            //Method for showing data
            Console.WriteLine("\n************************");
            Console.WriteLine("Your ticket name is: " + name);
            Console.WriteLine("Your ticket price is: " + price.ToString("C", CultureInfo.CurrentCulture));
            Console.WriteLine("Your ticket include " + numOfAdults + " adults and " + numOfChildren + " children");
            Console.WriteLine("Your amount to pay is: " + amountToPay.ToString("C", CultureInfo.CurrentCulture));
            Console.WriteLine("************************");
        }
        public void ReadAndSaveTicketData()
        {
            Console.WriteLine("Enter your ticket name:"); //Ask for input
            string? v = Console.ReadLine(); //Save input in a opt variable
            name = string.IsNullOrEmpty(v) ? "undefined" : v.Trim(); //If string is null I save it as undefined
            Console.WriteLine("How many adults:"); //Ask for input
            v = Console.ReadLine(); //Save input in a opt variable
            //If string is null or not a digit I save this as 0
            numOfAdults = int.Parse(string.IsNullOrEmpty(v) ? "0" : (v.All(char.IsDigit)) ? v : "0");
            Console.WriteLine("How many children (children pay a quarter of the ticket price):"); //Ask for input
            v = Console.ReadLine(); //Save input in a opt variable
            //If string is null or not a digit I save this as 0
            numOfChildren = int.Parse(string.IsNullOrEmpty(v) ? "0" : (v.All(char.IsDigit)) ? v : "0");
            amountToPay = price * numOfAdults + price * numOfChildren * 0.25; //Calculate amount to pay
        }
    }
}
