﻿using System;
using Greenhouse;

namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Prepare console in a method, giving colors and title as parameters
            PrepareConsoleLook(ConsoleColor.Green, ConsoleColor.Black, "Greenhouse");
            Console.WriteLine("Grenhouse DataBase System\n");

            //Loop until user says stop
            do {
                //Create a plant obj and calling start method
                Greenhouse.Plant plant = new();
                plant.Start();
                Console.WriteLine("\nDo you want to add another plant to the system?(y/n)");
            }while(!Console.ReadLine().Trim().Equals("n"));

            Console.WriteLine("\nThank you for trying this program. Press enter to close this program");
            Console.ReadLine();
        }
        static void PrepareConsoleLook(ConsoleColor backgroundColor, ConsoleColor foregroundColor, string title)
        {
            Console.BackgroundColor = backgroundColor;
            Console.Clear();
            Console.ForegroundColor = foregroundColor;
            Console.Title = title;
        }
    }
}