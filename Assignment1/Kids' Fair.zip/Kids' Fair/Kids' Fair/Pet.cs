﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kids__Fair
{
    internal class Pet
    {
        private int age; //Variable for pet age
        private bool isFemale; //Variable for pet sex
        private string name = string.Empty; //Variable for pet name, init as empty string
        public Pet()
        {
        }
        public void Start()
        {
            ReadAndSavePetData();
            DisplayPetInfo();
        }
        public void DisplayPetInfo()
        {
            //Method to show all data
            Console.WriteLine("\n************************");
            Console.WriteLine("Your pet name is " + name);
            //If age equals -1 -> undefined
            Console.WriteLine("Your pet age is " + ((age != -1) ? age : "undefined"));
            //If isFemaile if default boolean value -> undefined
            Console.WriteLine("Your pet is a " + ((isFemale == true) ? "female" : "male"));
            Console.WriteLine("************************");
        }
        public void ReadAndSavePetData()
        {
            Console.WriteLine("Enter your pet name:"); //Ask for input
            string? v = Console.ReadLine(); //Save input in a opt variable
            name = string.IsNullOrEmpty(v) ? "undefined" : v.Trim();
            Console.WriteLine("Enter your pet age:"); //Ask for input
            v = Console.ReadLine(); //Save input in a opt variable
            //If string is null or not a digit I save this as -1
            age = int.Parse(string.IsNullOrEmpty(v) ? "-1" : (v.All(char.IsDigit)) ? v.Trim() : "-1");
            Console.WriteLine("Is your pet a female (y/n)?"); //Ask for input
            v = Console.ReadLine(); //Save input in a opt variable
            isFemale = string.IsNullOrEmpty(v) ? false : ((v.Trim().Equals("y") || v.Trim().Equals("yes")) ? true : false);
        }
    }
}
