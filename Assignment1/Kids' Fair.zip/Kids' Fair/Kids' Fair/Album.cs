﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Kids__Fair
{
    internal class Album
    {
        private string albumName = string.Empty; //Variable for album name, init as empty string
        private string artistName = string.Empty; //Variable for artist name, init as empty string
        private int numOfTracks; //Variable for number of tracks
        public Album()
        {
        }
        public void Start()
        {
            ReadAndSaveTicketData(); //Read and save input
            DisplayTicketInfo(); //Show data
        }
        public void DisplayTicketInfo()
        {
            //Show all data method
            Console.WriteLine("\n************************");
            //If track number is -1, aka non digit or null/empty, I show undefined
            Console.WriteLine("Your album is named " + albumName + " from the artist " + artistName + " and it contains " + (numOfTracks != -1 ? numOfTracks : "an undefined number of") + " tracks");
            Console.WriteLine("************************");
        }
        public void ReadAndSaveTicketData()
        {
            Console.WriteLine("Enter your album name:"); //Ask for input
            string? v = Console.ReadLine(); //Save input in a opt variable
            albumName = string.IsNullOrEmpty(v) ? "undefined" : v.Trim(); //Save input as undefined if null
            Console.WriteLine("Enter your artist name:"); //Ask for input
            v = Console.ReadLine(); //Save input in a opt variable
            artistName = string.IsNullOrEmpty(v) ? "undefined" : v.Trim(); //Save input as undefined if null
            Console.WriteLine("Enter you album number of tracks:"); //Ask for input
            v = Console.ReadLine(); //Save input in a opt variable
            //Save input as -1 if null and then check if input is a digit so I can parse, if not I save as -1
            numOfTracks = int.Parse(string.IsNullOrEmpty(v) ? "-1" : (v.All(char.IsDigit)) ? v : "-1");
        }
    }
}
