﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Globalization;

namespace Greenhouse
{
    internal class Plant
    {
        private string name = string.Empty; //Name of the plant
        private double price; //price of the plants
        private string description = string.Empty; //Description of the plant
        private int numOfPlants; //Number of plants
        public void Start()
        {
            ReadAndSavePlantData(); //Method to insert plant
            DisplayPlantInfo(); //Method to show plant
        }
        public void DisplayPlantInfo()
        {
            Console.WriteLine("\n******[" + DateTime.Now + "]************"); //Show DateTime
            Console.WriteLine("Your plant name is " + name); //Show data
            Console.WriteLine("Your plant is " + description); //Show data
            Console.WriteLine("A singular plant price is: " + price.ToString("C", CultureInfo.CurrentCulture)); //Show data
            //Show data based on num of plants and price
            Console.WriteLine("You actually have " + numOfPlants + " total plants in your greenhouse, for a total of " + (numOfPlants*price).ToString("C", CultureInfo.CurrentCulture) + " worth");
            Console.WriteLine("***************************************");
        }
        public void ReadAndSavePlantData()
        {
            Console.WriteLine("Enter your plant name:"); //Ask for input
            string? v = Console.ReadLine(); //Save input in a opt variable
            name = string.IsNullOrEmpty(v) ? "undefined" : v.Trim(); //Save input as undefined if null
            Console.WriteLine("Describe how your plant looks like:"); //Ask for input
            v = Console.ReadLine(); //Save input in opt var
            description = string.IsNullOrEmpty(v) ? "undefined" : v; //Save input as undefined if null
            Console.WriteLine("How many plants do you want?"); //Ask for input
            v = Console.ReadLine(); //Save input in opt var
            numOfPlants = string.IsNullOrEmpty(v) ? 0 : int.Parse(v.Trim()); //Save input as undefined if null
            Console.WriteLine("What is the plant price?"); //Ask for input
            v = Console.ReadLine(); //Save input in opt var
            price = string.IsNullOrEmpty(v) ? 0 : float.Parse(v.Trim()); //Save input as undefined if null
        }
    }
}
